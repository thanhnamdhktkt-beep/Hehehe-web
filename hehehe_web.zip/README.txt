# hehehe Web

Static website generated from the supplied HTML file.

## Deploy
Upload `index.html` to any static hosting service that supports HTTPS.

## Entry point
`index.html`
